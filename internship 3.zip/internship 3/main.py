import requests
from bs4 import BeautifulSoup
import pandas as pd
url = "https://in.seamsfriendly.com/"

r = requests.get(url)
# print(r.content)
soup = BeautifulSoup(r.content, 'html.parser')
# print(soup.title.string)    # Print Title in String

''' Print TITLE'''
title = soup.title.string
print(title)


''' Print all image urls '''

anchors = soup.find_all('a')
al_links = set()
for links in anchors:
    if(links.get('href') != '#'):
        linklist = 'https://in.seamsfriendly.com' + links.get('href')
        al_links.add(links)
        print(linklist)

''' Print all PRICE'''

price = soup.find_all(
    class_='ProductItem__Price Price Text--subdued')

print(price)


''' Print DESCIPTIONS'''
description = soup.find(class_='fendtext')
print(description.text.split('.'))

''' Converting them to csv file'''
data = [[url, title, linklist, price, description]]

df = pd.DataFrame(
    data, columns=['url', 'Ttile', 'Image urls', 'Price', 'Descriptions'])
print(df)
df.to_csv('intern.csv',index=False)
